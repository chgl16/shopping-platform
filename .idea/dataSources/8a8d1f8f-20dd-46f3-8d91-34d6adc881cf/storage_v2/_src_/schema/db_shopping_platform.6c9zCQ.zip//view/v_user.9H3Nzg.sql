create view v_user as
  select `db_shopping_platform`.`tb_user`.`pk_id`               AS `id`,
         `db_shopping_platform`.`tb_user`.`uk_phone`            AS `phone`,
         `db_shopping_platform`.`tb_user`.`role_type`           AS `role_type`,
         `db_shopping_platform`.`tb_userinfo`.`username`        AS `username`,
         `db_shopping_platform`.`tb_userinfo`.`img_url`         AS `img_url`,
         `db_shopping_platform`.`tb_userinfo`.`contact_phone`   AS `contact_phone`,
         `db_shopping_platform`.`tb_userinfo`.`contact_address` AS `contact_address`
  from `db_shopping_platform`.`tb_user`
         join `db_shopping_platform`.`tb_userinfo`
  where (`db_shopping_platform`.`tb_user`.`pk_id` = `db_shopping_platform`.`tb_userinfo`.`pk_id`);

